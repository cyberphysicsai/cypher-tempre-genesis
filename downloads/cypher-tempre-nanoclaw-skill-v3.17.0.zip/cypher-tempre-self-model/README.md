# Cypher Tempre Timechain Self-Model

**Runtime label:** NanoClaw skill version.

This is the NanoClaw bundle for Cypher Tempre: a persistent, verifiable,
self-healing cognitive self-model for an AI agent. It is stdlib-only Python,
uses NanoClaw-discoverable frontmatter, and ships without generated memory state.

## Install

Copy this folder into NanoClaw's configured workspace skills directory:

```bash
cp -R cypher-tempre-self-model /path/to/nanoclaw/skills/
```

Refresh NanoClaw's skill list, then initialize a fresh chain inside the copied
bundle:

```bash
python3 timechain.py init --name NanoClaw
python3 timechain.py verify
```

See `SKILL.md` for the full per-turn protocol.


## Data retention & third-party transmission

This skill is a **persistent memory system**. By design it records each turn — your
request and the agent's decision — into an append-only, hash-chained ledger under
`chain/` that is **never deleted** (history is immutable; that tamper-evidence is the
point). Treat it like a local journal:

- **Everything is stored locally, in cleartext.** Do not feed it secrets, credentials,
  or PII you would not want retained indefinitely. The chain is tamper-EVIDENT, not
  encrypted, and there is no built-in redaction or expiry.
- **It stays on your machine by default.** The core engine is stdlib-only and the
  default embedder is local; nothing is transmitted off-machine.
- **Optional embedding providers send text to a third party.** If you explicitly enable
  the OpenAI / Voyage / sentence-transformers backends (they need an API key or extra
  library and are OFF by default), the text being embedded — which may include memory
  chunks, source excerpts, or other chain contents — is sent to that provider. Keep the
  default local `hashing` embedder if that is a concern.
